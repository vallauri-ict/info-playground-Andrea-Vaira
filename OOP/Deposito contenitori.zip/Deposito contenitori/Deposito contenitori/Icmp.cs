﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deposito_contenitori
{
    interface Icmp
    {
        void confronta(Contenitore c1, Contenitore c2);
    }
}
