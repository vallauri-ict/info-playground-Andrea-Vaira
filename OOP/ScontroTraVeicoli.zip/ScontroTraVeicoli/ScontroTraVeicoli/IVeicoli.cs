﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScontroTraVeicoli
{
    interface IVeicoli
    {
        Veicolo Scontro(Veicolo v1, Veicolo v2);
    }
}
